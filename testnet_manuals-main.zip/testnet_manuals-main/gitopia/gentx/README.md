# Generate gentx for janus-1 incentivized testnet
```
wget -O janus_gentx.sh https://raw.githubusercontent.com/kj89/testnet_manuals/main/gitopia/gentx/janus_gentx.sh && chmod +x janus_gentx.sh && ./janus_gentx.sh
```

Things you have to backup:
- wallet `24 word mnemonic` generated in output
- contents of `$HOME/.gitopia/config/`"
