<p style="font-size:14px" align="right">
<a href="https://kjnodes.com/" target="_blank">Visit our website <img src="https://user-images.githubusercontent.com/50621007/168689709-7e537ca6-b6b8-4adc-9bd0-186ea4ea4aed.png" width="30"/></a>
<a href="https://discord.gg/EY35ZzXY" target="_blank">Join our discord <img src="https://user-images.githubusercontent.com/50621007/176236430-53b0f4de-41ff-41f7-92a1-4233890a90c8.png" width="30"/></a>
<a href="https://kjnodes.com/" target="_blank">Visit our website <img src="https://user-images.githubusercontent.com/50621007/168689709-7e537ca6-b6b8-4adc-9bd0-186ea4ea4aed.png" width="30"/></a>
</p>

<p style="font-size:14px" align="right">
<a href="https://hetzner.cloud/?ref=y8pQKS2nNy7i" target="_blank">Deploy your VPS using our referral link to get 20€ bonus <img src="https://user-images.githubusercontent.com/50621007/174612278-11716b2a-d662-487e-8085-3686278dd869.png" width="30"/></a>
</p>

<p align="center">
  <img height="100" height="auto" src="https://user-images.githubusercontent.com/50621007/177323789-e6be59ae-0dfa-4e86-b3a8-028a4f0c465c.png">
</p>

# Get service agreement from an indexer (50 points)
This task can be completed in parallel with the task [Accept an offer from the marketplace](https://github.com/kj89/testnet_manuals/blob/main/subquery/tasks/Indexer_to_accept_an_offer_in_the_offer_market.md)

>You have to purchase your own `Offer` using other account or ask someone to do so by providing your `Indexer Address`

1. Go to the [Offer Marketplace](https://frontier.subquery.network/plans/offers) and use search to find your `Offer` from the list

![image](https://user-images.githubusercontent.com/50621007/177424847-1f0bde35-fdb1-4f3a-a929-e50125e7fe82.png)

2. Click `Accept` and sign the transaction

![image](https://user-images.githubusercontent.com/50621007/177424878-c530c442-d477-49eb-9196-ae6f0abf9260.png)

# Task Finished!

![image](https://user-images.githubusercontent.com/50621007/177410026-f15d1fd1-42f2-40b6-b5a6-16d84c152675.png)

Check progress of your tasks and points earned at [Missions Dashboard](https://frontier.subquery.network/missions/my-missions)
