<p style="font-size:14px" align="right">
<a href="https://kjnodes.com/" target="_blank">Visit our website <img src="https://user-images.githubusercontent.com/50621007/168689709-7e537ca6-b6b8-4adc-9bd0-186ea4ea4aed.png" width="30"/></a>
<a href="https://discord.gg/EY35ZzXY" target="_blank">Join our discord <img src="https://user-images.githubusercontent.com/50621007/176236430-53b0f4de-41ff-41f7-92a1-4233890a90c8.png" width="30"/></a>
<a href="https://kjnodes.com/" target="_blank">Visit our website <img src="https://user-images.githubusercontent.com/50621007/168689709-7e537ca6-b6b8-4adc-9bd0-186ea4ea4aed.png" width="30"/></a>
</p>

<p style="font-size:14px" align="right">
<a href="https://hetzner.cloud/?ref=y8pQKS2nNy7i" target="_blank">Deploy your VPS using our referral link to get 20€ bonus <img src="https://user-images.githubusercontent.com/50621007/174612278-11716b2a-d662-487e-8085-3686278dd869.png" width="30"/></a>
</p>

<p align="center">
  <img height="100" height="auto" src="https://user-images.githubusercontent.com/50621007/177323789-e6be59ae-0dfa-4e86-b3a8-028a4f0c465c.png">
</p>

# Consumer purchase a plan from an indexer (50 points)
1. Go to [Explorer, section Indexers](https://frontier.subquery.network/explorer/project/0x01/overview) and find the desired Indexer using search, open the list of its plans and click "Purchase"

![image](https://user-images.githubusercontent.com/50621007/177421297-8ed5c8d8-f425-49b4-8a5e-68014791292b.png)

2. Complete your plan purchase

![image](https://user-images.githubusercontent.com/50621007/177421537-2703ad91-bcaa-481e-882d-22a5d1531bd1.png)

# Task Finished!

![image](https://user-images.githubusercontent.com/50621007/177421810-d3ab9f52-6be7-4197-a6bb-b8d8d56049b9.png)

Check progress of your tasks and points earned at [Missions Dashboard](https://frontier.subquery.network/missions/my-missions)
