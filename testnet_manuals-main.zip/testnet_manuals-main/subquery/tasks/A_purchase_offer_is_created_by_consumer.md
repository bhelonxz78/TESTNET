<p style="font-size:14px" align="right">
<a href="https://kjnodes.com/" target="_blank">Visit our website <img src="https://user-images.githubusercontent.com/50621007/168689709-7e537ca6-b6b8-4adc-9bd0-186ea4ea4aed.png" width="30"/></a>
<a href="https://discord.gg/EY35ZzXY" target="_blank">Join our discord <img src="https://user-images.githubusercontent.com/50621007/176236430-53b0f4de-41ff-41f7-92a1-4233890a90c8.png" width="30"/></a>
<a href="https://kjnodes.com/" target="_blank">Visit our website <img src="https://user-images.githubusercontent.com/50621007/168689709-7e537ca6-b6b8-4adc-9bd0-186ea4ea4aed.png" width="30"/></a>
</p>

<p style="font-size:14px" align="right">
<a href="https://hetzner.cloud/?ref=y8pQKS2nNy7i" target="_blank">Deploy your VPS using our referral link to get 20€ bonus <img src="https://user-images.githubusercontent.com/50621007/174612278-11716b2a-d662-487e-8085-3686278dd869.png" width="30"/></a>
</p>

<p align="center">
  <img height="100" height="auto" src="https://user-images.githubusercontent.com/50621007/177323789-e6be59ae-0dfa-4e86-b3a8-028a4f0c465c.png">
</p>

# A purchase offer is created by consumer (50 points)
1. Open `Manage My Offers` section in [Plan & Offer](https://frontier.subquery.network/plans/my-offers/open) then click `Create an Offer`

![image](https://user-images.githubusercontent.com/50621007/177412441-86e9ffd6-8b0a-4f73-9493-62065be8dcb8.png)

2. Confirm Approval

![image](https://user-images.githubusercontent.com/50621007/177411364-04f4e522-c268-4dea-8dbb-9952e9005360.png)

3. After confirmation, click on `Create an Offer` again and search for a project by ID: `QmduAur8aCENpuizuTGLAsXumG2BX8zSgWLsVpp5b8GEGN`

![image](https://user-images.githubusercontent.com/50621007/177411770-59eeb218-d90f-4930-ba74-eb9c90f12011.png)

4. Next, follow the example in the screenshots below

![image](https://user-images.githubusercontent.com/50621007/177411946-aa817193-4e82-4c21-be43-78b6e0a85f50.png)

5. Set the details for your offer

![image](https://user-images.githubusercontent.com/50621007/177412250-ba57cf50-f739-4887-8cf9-e1162d7a5d6d.png)

6. Confirm Offer

![image](https://user-images.githubusercontent.com/50621007/177412302-630de06e-9074-4d66-b6da-7e0600029e59.png)

Checking the execution of the task:

# Task Finished!

![image](https://user-images.githubusercontent.com/50621007/177412343-cb859924-12de-4f65-ae97-248340fd9e0a.png)

Check progress of your tasks and points earned at [Missions Dashboard](https://frontier.subquery.network/missions/my-missions)
