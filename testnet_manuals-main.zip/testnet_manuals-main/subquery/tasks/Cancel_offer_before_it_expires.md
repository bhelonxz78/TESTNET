<p style="font-size:14px" align="right">
<a href="https://kjnodes.com/" target="_blank">Visit our website <img src="https://user-images.githubusercontent.com/50621007/168689709-7e537ca6-b6b8-4adc-9bd0-186ea4ea4aed.png" width="30"/></a>
<a href="https://discord.gg/EY35ZzXY" target="_blank">Join our discord <img src="https://user-images.githubusercontent.com/50621007/176236430-53b0f4de-41ff-41f7-92a1-4233890a90c8.png" width="30"/></a>
<a href="https://kjnodes.com/" target="_blank">Visit our website <img src="https://user-images.githubusercontent.com/50621007/168689709-7e537ca6-b6b8-4adc-9bd0-186ea4ea4aed.png" width="30"/></a>
</p>

<p style="font-size:14px" align="right">
<a href="https://hetzner.cloud/?ref=y8pQKS2nNy7i" target="_blank">Deploy your VPS using our referral link to get 20€ bonus <img src="https://user-images.githubusercontent.com/50621007/174612278-11716b2a-d662-487e-8085-3686278dd869.png" width="30"/></a>
</p>

<p align="center">
  <img height="100" height="auto" src="https://user-images.githubusercontent.com/50621007/177323789-e6be59ae-0dfa-4e86-b3a8-028a4f0c465c.png">
</p>

# Cancel offer before it expires (30 points)

1. To complete this task we have to create an offer, as described in the task [A purchase offer is created by consumer](https://github.com/kj89/testnet_manuals/blob/main/subquery/tasks/A_purchase_offer_is_created_by_consumer.md), and cancel it before it expires.

![image](https://user-images.githubusercontent.com/50621007/177415906-528925c3-d823-48b9-ace3-67a23e072541.png)

2. Confirm Cancellation

![image](https://user-images.githubusercontent.com/50621007/177416208-35de2347-aafa-4d28-a8cc-d7554f8b4d38.png)

# Task Finished!

![image](https://user-images.githubusercontent.com/50621007/177416110-59330d9c-9e55-451e-bf42-61622bddf570.png)

Check progress of your tasks and points earned at [Missions Dashboard](https://frontier.subquery.network/missions/my-missions)
