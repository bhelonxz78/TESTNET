Vote YES on the Rhye upgrade proposal #6 
```
quicksilverd tx gov vote 6 yes --from $WALLET --chain-id=$QUICKSILVER_CHAIN_ID
```
Vote NO on proposal #5
```
quicksilverd tx gov vote 5 no --from $WALLET --chain-id=$QUICKSILVER_CHAIN_ID
```
