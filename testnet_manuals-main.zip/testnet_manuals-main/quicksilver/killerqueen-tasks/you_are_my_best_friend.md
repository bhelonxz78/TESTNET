Redelegate from your validator 1 qkc token to our validator
```
quicksilverd tx staking redelegate $QUICKSILVER_VALOPER_ADDRESS quickvaloper1v84k3l35a2kxu966vyd59fakpmdjjukgx0n0ls 1000000uqck --from=$WALLET --chain-id=$QUICKSILVER_CHAIN_ID --gas=auto --gas-adjustment 1.4 --yes
```
