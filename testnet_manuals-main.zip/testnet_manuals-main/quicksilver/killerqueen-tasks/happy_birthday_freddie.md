Set commission rate to 5.9% (Freddie Mercury's Birthday is 5/9)
```
quicksilverd tx staking edit-validator --moniker=$NODENAME --chain-id=$QUICKSILVER_CHAIN_ID --from=$WALLET --commission-rate "0.059"
```
