Vote on proposal-3 to add kqcosmos-1 as a liquid staking zone
```
quicksilverd tx gov vote 3 yes --from $WALLET --chain-id=$QUICKSILVER_CHAIN_ID
```
