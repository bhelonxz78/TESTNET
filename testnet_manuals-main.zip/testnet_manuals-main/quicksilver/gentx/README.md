<p style="font-size:14px" align="right">
<a href="https://kjnodes.com/" target="_blank">Visit our website <img src="https://user-images.githubusercontent.com/50621007/168689709-7e537ca6-b6b8-4adc-9bd0-186ea4ea4aed.png" width="30"/></a>
<a href="https://discord.gg/EY35ZzXY" target="_blank">Join our discord <img src="https://user-images.githubusercontent.com/50621007/176236430-53b0f4de-41ff-41f7-92a1-4233890a90c8.png" width="30"/></a>
<a href="https://kjnodes.com/" target="_blank">Visit our website <img src="https://user-images.githubusercontent.com/50621007/168689709-7e537ca6-b6b8-4adc-9bd0-186ea4ea4aed.png" width="30"/></a>
</p>

<p style="font-size:14px" align="right">
<a href="https://hetzner.cloud/?ref=y8pQKS2nNy7i" target="_blank">Deploy your VPS using our referral link to get 20€ bonus <img src="https://user-images.githubusercontent.com/50621007/174612278-11716b2a-d662-487e-8085-3686278dd869.png" width="30"/></a>
</p>

<p align="center">
  <img height="100" height="auto" src="https://user-images.githubusercontent.com/50621007/166148846-93575afe-e3ce-4ca5-a3f7-a21e8a8609cb.png">
</p>

# Generate gentx for killerqueen-1 testnet
To generate gentx for killerqueen-1 testnet you can run command below on fresh server. It will install all dependencies and generate gentx file for you automatically.
```
wget -O killerqueen_gentx.sh https://raw.githubusercontent.com/kj89/testnet_manuals/main/quicksilver/gentx/killerqueen_gentx.sh && chmod +x killerqueen_gentx.sh && ./killerqueen_gentx.sh
```

Things you have to backup:
- wallet `24 word mnemonic` generated in output
- contents of `$HOME/.quicksilverd/config/`

# Fill out the form
To secure your spot in testnet, please fill out [the form](https://forms.gle/VMfagKN3sDrKYpE38) before Monday, June 20
